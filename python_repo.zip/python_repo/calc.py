import re
s = raw_input()
l = re.findall('[+-/*//]|\d+',s)
if(l[1] == "+"):
	print int(l[0]) + int(l[2])
elif(l[1] == "-"):
	print int(l[0]) - int(l[2])
elif(l[1] == "*"):
	print int(l[0]) * int(l[2])
elif(l[1] == "/"):
	print int(l[0]) / int(l[2])
else:
	print("Syntax error")

