n = input()
v = list(map(int, input().split(' ')))
x = max(v)
y = []
for i in range(0,len(v)):
	if(v[i] != x):
		y.append(v[i])
print(max(y))
