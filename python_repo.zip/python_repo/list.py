thislist = ["apple", "banana", "cherry"]
thislist.pop(1)
print(thislist)
