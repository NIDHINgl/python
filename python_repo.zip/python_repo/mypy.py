print("Enter a number:")
a = input()
if 5 > a:
	print("  h el     lo world  ")
	x = "hello world"
	y = 8
	z = int(2.9)
	print(x[1])
	print(x[2:5])
	print(x.split())
else:
	print("hi")