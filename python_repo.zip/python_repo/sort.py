a = [1,6,2,9,10,2]
a.sort(reverse = True)
c = []
i = 1
for x in range(len(a)+1):
	if(a[i] == a[0]):
		i += 1
	else:
		c.append(a[i])
		i += 1
print(max(c))

