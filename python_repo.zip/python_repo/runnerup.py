n = raw_input()
v = map(int, raw_input().split())
a = b = -100 

for i in range(0, len(v)):
	if(v[i] > a):
		a = v[i]
		print(a)

	for i in range(0, len(v)):
		print(v[i])
		if(v[i] > b and v[i] < a):
			b = v[i]

print b